# AWS Well-Architected Framework, IaC Alternatives & the 12-Factor App

**Feedback addressed:** *"learn the Well-Architected pillars and common IaC alternatives well enough to explain trade-offs rather than just naming them"* + *"prioritize evaluating multiple options... comparing Terraform with alternatives like CloudFormation or CDK"* + *"familiarize with 12-factor applications."*

## 1. The Six Well-Architected Pillars (with a one-line trade-off angle for each)

| Pillar | What it asks | Interview-ready trade-off line |
|---|---|---|
| **Operational Excellence** | Can you run and improve the system reliably (IaC, runbooks, automation)? | "We automated deploys via GitLab CI/Terraform, trading some initial pipeline complexity for repeatable, auditable releases." |
| **Security** | Least privilege, data protection, incident response | "We used Vault/JFrog auth integration instead of static credentials, trading setup effort for reduced secret-sprawl risk." |
| **Reliability** | Recovery, fault isolation, scaling | "Isolated state backends per test subfolder trade a bit of pipeline overhead for blast-radius containment — one failing module can't corrupt another's state." |
| **Performance Efficiency** | Right-sizing, matching resource to workload | "Parallel child pipelines trade higher concurrent compute cost for much shorter feedback loops." |
| **Cost Optimization** | Eliminate waste, right resource for the job | "Moving to Prometheus/Thanos/Grafana traded operational ownership (self-managed stack) for ~$50–60K/yr in licensing savings." |
| **Sustainability** | Minimize environmental footprint | "Removing unused resources doubles as a cost and sustainability win — fewer idle instances/storage." |

Use **all six**, not just cost/ops, when asked "how did you evaluate this design" — the panel specifically wants pillar-level fluency.

## 2. Terraform vs CloudFormation vs CDK — the Trade-off Table

| Dimension | Terraform | CloudFormation | AWS CDK |
|---|---|---|---|
| Cloud scope | Multi-cloud (AWS, Azure, GCP, etc.) | AWS-only | AWS-only (compiles to CloudFormation) |
| Language | HCL (declarative DSL) | JSON/YAML (declarative) | TypeScript/Python/Java (imperative-feeling, generates declarative templates) |
| State management | Explicit remote state file you own (S3+lock table, etc.) | Managed by AWS (stack state) | Managed by AWS via CloudFormation |
| Learning curve | Moderate — new DSL, but consistent across providers | Low if AWS-only shop, verbose YAML/JSON | Higher — need real programming idioms + CFN concepts underneath |
| Drift detection | `terraform plan` shows drift; requires discipline to run regularly | Native drift detection in console | Inherits CloudFormation drift detection |
| Modularity/reuse | Strong module ecosystem (registry, custom modules) | Nested stacks, less ergonomic reuse | Constructs — very strong reuse/abstraction, OOP-style |
| Team fit | Best if the org already spans multiple clouds or wants provider-agnostic skills | Best for AWS-only shops wanting zero extra tooling | Best for teams that want to write infra in a general-purpose language, e.g. embed logic/loops naturally |
| Vendor lock-in risk | Low (provider swap possible, though modules aren't portable) | High (AWS-native) | High (AWS-native, CFN underneath) |

**Your actual answer (say this, not just the table):**
> "We used Terraform because the team already had multi-account, and in some contexts multi-cloud-adjacent needs (Azure naming alignment), so a provider-agnostic tool avoided re-tooling. The trade-off was owning our own remote state (S3 + lock), versus CloudFormation's managed state — we accepted that operational overhead because it gave us portability and a mature module ecosystem. CDK wasn't chosen because the team's strength was HCL/declarative patterns, not a general-purpose language for infra, and we didn't need CDK's programmatic abstractions for our fairly templated module use case."

## 3. The 12-Factor App Methodology (know all 12, be ready to map 2–3 to your work)

1. **Codebase** — one codebase tracked in revision control, many deploys
2. **Dependencies** — explicitly declare and isolate
3. **Config** — store config in the environment, not code
4. **Backing services** — treat as attached resources (DB, cache, queue)
5. **Build, release, run** — strictly separate these stages
6. **Processes** — execute the app as one or more stateless processes
7. **Port binding** — export services via port binding
8. **Concurrency** — scale out via the process model
9. **Disposability** — fast startup and graceful shutdown
10. **Dev/prod parity** — keep environments as similar as possible
11. **Logs** — treat logs as event streams
12. **Admin processes** — run admin/management tasks as one-off processes

**Map to your work:** "Our GitLab pipelines already respect Build/Release/Run separation — the same artifact is built once and promoted through environments. Config (factor 3) is injected via Terraform variables and Vault rather than baked into images, and Logs (factor 11) flow to our Prometheus/Fluentd stack as streams rather than files on disk."

## 4. Likely Follow-up Questions
- "Which Well-Architected pillar did you trade off against another, and why?" (Answer: Performance Efficiency vs Cost — parallel pipelines cost more compute but win on speed.)
- "If your org went multi-cloud tomorrow, would CDK still make sense?" (No — CDK is AWS/CFN-bound; Terraform or Pulumi would be the candidates.)
- "Which 12-factor principle is hardest for your current system to satisfy?" (Be honest — likely Config or Dev/prod parity if secrets/environments differ meaningfully.)
