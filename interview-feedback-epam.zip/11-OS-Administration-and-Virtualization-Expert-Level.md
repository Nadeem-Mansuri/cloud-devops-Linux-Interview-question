# OS Administration (Expert gap) & Virtualization (Advanced gap)

**Feedback addressed — OS Administration:** *"No concrete evidence of solving complex OS subsystems or kernel-level issues... Limited evidence of administration across multiple OS/distributions and custom image building/upgrades... No examples of large-scale OS architecture changes or deep subsystem root-cause analyses."*
**Feedback addressed — Virtualization:** *"lack of demonstrated leadership in designing enterprise cloud strategies or migrations... insufficient evidence of disaster recovery/backup and large-scale cloud platform build experience."*

This is your largest single gap (2 levels on OS Administration). Treat it as the highest-effort item in the plan.

## 1. OS Administration — What "Expert" Evidence Looks Like
| Current evidence (Intermediate) | Expert-level evidence needed |
|---|---|
| RHCSA cert, daily Linux use, OpenStack/virtualization exposure | Root-caused a kernel/subsystem-level incident (e.g., memory pressure, OOM killer behavior, filesystem corruption, network stack tuning) |
| Practical use in CI/CD and Docker | Built/maintained custom OS images (golden AMIs/hardened images) with a repeatable pipeline |
| — | Administered more than one distro/family (e.g., RHEL + Ubuntu/Debian + a container-optimized OS like Bottlerocket) and can speak to real differences |

### Key Linux Subsystems to Be Ready to Discuss
- **Memory management:** OOM killer (`oom_score_adj`), page cache vs application memory, swappiness tuning
- **Filesystem/storage:** inode exhaustion, disk I/O bottlenecks (`iostat`, `iotop`), LVM, filesystem choice trade-offs (ext4 vs XFS)
- **Process/CPU:** load average interpretation (it's not just "CPU busy" — includes uninterruptible I/O wait), cgroups for resource limiting (directly relevant to container runtimes)
- **Networking stack:** `conntrack` table exhaustion (common under high-connection-count workloads), TCP tuning (`net.core.somaxconn`, `net.ipv4.tcp_tw_reuse`)

**A believable "root cause" narrative to develop (adapt to something real from your history):**
> "We saw intermittent connection failures under load. Standard app-level logs showed nothing. Digging into the kernel network stack, `conntrack -S` showed the connection-tracking table hitting its max, causing new connections to be silently dropped. Root cause was `nf_conntrack_max` set too low for our EKS node's actual connection churn. Fix was tuning the sysctl value and adding it to our custom AMI build, plus a monitoring alert on conntrack table utilization going forward." — *(Only use this if something like it genuinely happened; otherwise use it as a study example of what a subsystem-level RCA narrative should sound like, and go find your own real instance.)*

### Custom Image Building (directly actionable, low effort/high signal)
- Tools: **Packer** (HashiCorp) for building golden AMIs; **EKS-optimized/Bottlerocket** base images for container nodes
- Practice: bake security hardening (CIS benchmarks), monitoring agents, and standard packages into the image at build time rather than via post-boot configuration — faster boot, more consistent fleet, reduced configuration drift
- **Concrete next step to cite:** "I'd formalize a Packer pipeline for our EKS node AMIs — baking in CIS-hardening, the Fluentd/Prometheus agents, and security patches — so nodes are consistent and audit-ready from first boot, rather than configured post-launch."

## 2. Virtualization — What "Advanced" Evidence Looks Like
| Current evidence (Intermediate) | Advanced-level evidence needed |
|---|---|
| RHCSA, OpenStack 210/310 certs, EKS/AWS ops experience | Designed or led an enterprise migration (e.g., on-prem VM estate → cloud, or hypervisor version upgrade across a fleet) |
| Daily hypervisor operations | Documented disaster recovery / backup strategy for virtualized workloads (RPO/RTO defined, tested failover) |
| — | Managed integrated server + storage + network deployment at enterprise scale |

### DR/Backup Concepts to Own (ties to your existing DR knowledge — reuse the RPO/RTO framing you likely already know from AWS database DR)
- **RPO (Recovery Point Objective)** — how much data loss is acceptable (time between backups)
- **RTO (Recovery Time Objective)** — how long recovery is allowed to take
- **Backup strategies for VMs:** snapshot-based (fast, storage-coupled) vs image/export-based (portable, slower) vs application-consistent backups (quiesce the OS/app before snapshot to avoid corrupt state)
- **Testing recovery, not just taking backups** — a backup you haven't restored from is unverified; mention a *periodic restore drill* as the maturity marker auditors/panels want to hear

**Talking point:** "We don't have a documented DR strategy for our virtualization layer today — that's a fair gap. My proposed next step would be defining an RPO/RTO target per workload tier, implementing scheduled snapshot backups with a tested quarterly restore drill, and documenting the runbook so recovery isn't tribal knowledge."

## 3. Cross-Cutting Advice for This File
Both gaps share the same root issue as the rest of the feedback (see Overview file): **evidence is project-scoped, not enterprise-scoped.** The fastest way to generate real evidence:
1. Volunteer for or propose the **golden AMI/Packer pipeline** — concrete, achievable in weeks, and directly closes both the "custom image building" and "OS architecture" gaps.
2. Draft a **one-page DR runbook** for your current virtualization/EKS footprint even informally — closes the "no DR evidence" gap without needing a full enterprise migration project.

## 4. Quick Answer Bank
- **"How do you decide RPO/RTO for a workload?"** — Business-driven: ask what data-loss window and downtime the business can tolerate for that specific workload tier, then reverse-engineer backup frequency/replication strategy from that, don't start from the technology.
- **"What's the risk of only using snapshot backups?"** — If not application-consistent, a snapshot can capture a mid-write, inconsistent state for databases — you may "have a backup" that doesn't actually restore cleanly.
- **"How would you approach standardizing OS images across a fleet?"** — Packer-based golden image pipeline, versioned like code, rebuilt on a schedule (patch cadence) rather than patched in place post-deployment.
