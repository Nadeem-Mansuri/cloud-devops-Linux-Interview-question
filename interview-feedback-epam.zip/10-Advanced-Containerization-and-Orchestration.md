# Advanced Containerization & Orchestration (Advanced-tier gap)

**Feedback addressed:** Container Orchestration Management (Advanced required, Intermediate current) and Containerization (Advanced required, Intermediate current). Specific gaps: *"no evidence of advanced workflows such as service mesh or RBAC tuning... limited discussion on advanced image optimization and supply-chain hardening... no examples of large-scale multi-cluster orchestration design."*

## 1. What You Already Have (confirmed strength)
- Deploying workloads to EKS via GitLab CI/CD
- Thanos sidecar pattern for Prometheus long-term retention
- Docker image scanning via AWS Inspector
- Discussion of image size/optimization

## 2. Gap A: Service Mesh
**What it is:** A dedicated infrastructure layer (usually sidecar-proxy based, e.g., Istio, Linkerd, AWS App Mesh) that handles service-to-service traffic concerns *outside* application code:
- **Traffic management** — canary/blue-green routing, retries, timeouts, circuit breaking
- **Security** — mutual TLS (mTLS) between services automatically, without app changes
- **Observability** — automatic per-hop metrics/traces (ties directly to File 05 OpenTelemetry)

**Talking point:** "We don't run a service mesh today — our EKS workloads communicate directly. The trade-off of adding one (e.g., Istio) would be automatic mTLS and fine-grained traffic splitting for canary releases, at the cost of added sidecar resource overhead and operational complexity. Given our current service count, it hasn't been a priority, but it would be the natural next step once we need canary deployments or zero-trust service-to-service security."

## 3. Gap B: RBAC Tuning (Kubernetes)
**Core objects to name correctly:**
- **Role / ClusterRole** — defines *what* actions (verbs: get/list/watch/create/update/delete) on *what* resources (pods, secrets, deployments)
- **RoleBinding / ClusterRoleBinding** — binds a Role/ClusterRole to a subject (user, group, or ServiceAccount)
- **ServiceAccount** — identity for pods/processes, not humans, to authenticate to the API server

**Example — least-privilege RBAC for a CI deploy service account:**
```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  namespace: app-team
  name: ci-deployer
rules:
- apiGroups: ["apps"]
  resources: ["deployments"]
  verbs: ["get", "list", "update", "patch"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: ci-deployer-binding
  namespace: app-team
subjects:
- kind: ServiceAccount
  name: gitlab-ci-deployer
roleRef:
  kind: Role
  name: ci-deployer
  apiGroup: rbac.authorization.k8s.io
```
**Talking point:** "Right now our GitLab CI likely uses a broader service account than strictly necessary. RBAC tuning means scoping that down to exactly the verbs/resources/namespaces the pipeline needs — e.g., `update` on Deployments in one namespace, not cluster-admin — which reduces blast radius if CI credentials are ever compromised."

## 4. Gap C: Image Optimization & Supply-Chain Hardening
| Technique | Why |
|---|---|
| **Multi-stage builds** | Build in a full SDK image, copy only the compiled artifact into a minimal runtime (e.g., `distroless`, `alpine`) — smaller attack surface & image size |
| **Distroless / minimal base images** | Removes shell, package manager, unnecessary binaries attackers could use post-compromise |
| **Image signing (Sigstore/cosign)** | Cryptographically verify an image wasn't tampered with between build and deploy |
| **SBOM (Software Bill of Materials)** | Generate a manifest of all packages/dependencies in the image for vulnerability tracking |
| **Pinned digests, not `:latest` tags** | Ensures reproducible, non-mutable deploys — `:latest` can silently change underneath you |
| **Scanning at multiple stages** | You already scan with AWS Inspector — "supply-chain hardening" extends this to scanning *base images* and *dependencies* pre-build, not just the final artifact |

**Talking point:** "We already scan built images with AWS Inspector. The next maturity step is shifting left — scanning base images and dependency manifests before build, adopting multi-stage builds with distroless runtimes to shrink the attack surface, and signing images (e.g., with cosign) so the cluster only runs verified artifacts."

## 5. Gap D: Multi-Cluster / Large-Scale Orchestration Design
Concepts to be conversational about even without direct experience:
- **Cluster topology models:** single large cluster vs multiple clusters (per environment, per region, per team) — trade-off is blast-radius isolation and independent upgrade cadence vs operational overhead of managing N clusters.
- **Multi-cluster tools:** Karmada, Cluster API, or a service mesh's multi-cluster mode for cross-cluster service discovery.
- **GitOps at scale:** Argo CD/Flux managing many clusters from a single source-of-truth repo, rather than manual `kubectl apply` per cluster.

**Honest positioning:** "I haven't designed a multi-cluster topology from scratch — our EKS footprint has been single-cluster per environment so far. If asked to design for scale, I'd start from GitOps (Argo CD) as the control plane for consistency across clusters, and only split clusters when there's a clear isolation need (blast radius, compliance boundary, or independent upgrade cadence) rather than by default."

## 6. Quick Answer Bank
- **"When would you NOT want a service mesh?"** — Small number of services, no cross-service mTLS/traffic-shaping requirement — the sidecar overhead and operational learning curve outweigh the benefit.
- **"How do you scope RBAC for a CI/CD service account?"** — Namespace-scoped Role (not ClusterRole) with only the verbs/resources the pipeline actually calls — start from zero permissions and add, not from cluster-admin and subtract.
- **"What's the fastest supply-chain-hardening win with the least effort?"** — Switch `:latest` tags to pinned digests and add base-image scanning pre-build — both are low-effort, high-signal wins before tackling image signing/SBOM.
