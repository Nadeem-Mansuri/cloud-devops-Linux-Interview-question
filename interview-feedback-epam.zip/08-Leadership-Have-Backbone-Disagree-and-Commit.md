# Leadership: "Have Backbone; Disagree and Commit" & Project Management Growth

**Feedback addressed:** *"Gain practical experience in team management and leadership by changing project roles. Focus on developing the leadership principle of 'Have Backbone; Disagree and Commit' as outlined in the Amazon Leadership Principles."*

## 1. The Principle, Precisely
> "Leaders are obligated to respectfully challenge decisions when they disagree, even when doing so is uncomfortable or exhausting. Leaders have conviction and are tenacious. They do not compromise for the sake of social cohesion. Once a decision is determined, they commit wholly."

Two distinct halves — most people only demonstrate one:
1. **Disagree** — voice the objection clearly, with reasoning/data, even to someone senior, even if it's socially costly.
2. **Commit** — once the decision is made (even against your recommendation), execute it fully and visibly, without relitigating it or quietly undermining it.

## 2. Why the Panel Flagged This Specifically for You
Your feedback shows strong **execution** and **ownership**, but leadership evidence so far reads as "led a small team, ran onboarding, hired people" — solid Intermediate leadership, but no story of *pushing back on a decision* and *later fully committing to it*. That's the specific evidence Lead-level leadership needs.

## 3. Building a Real STAR Story for This (do this before the next assessment)
Think back through your project history for a moment where:
- You disagreed with a technical or process decision (a manager's, an architect's, a client's)
- You raised the disagreement with reasoning, not just an opinion
- The decision went a different way than you argued for
- You then executed the decision fully and effectively anyway

**Template:**
```
Situation: <decision being made, e.g., architecture choice, tooling, timeline>
My position: <what you argued for, and why — cite data/trade-offs>
The disagreement moment: <how you raised it — to whom, how directly>
Outcome: <what was decided, was it your view or not>
Commitment: <how you executed the actual decision fully afterward,
            evidence you didn't undermine or relitigate it>
Result: <what happened, ideally with a number>
```

**If you genuinely don't have a strong example yet:** say so honestly, and pivot to a forward-looking answer:
> "I haven't had a strong test of this yet because most of my technical calls have gone through without major pushback needed. If I disagreed with a decision I couldn't win — say a client insisting on a design I thought was cost-inefficient — I'd document my reasoning and quantified concern once, clearly, to the decision-maker, and if overruled, execute it fully and monitor for the specific risk I flagged, so I could raise it again with evidence if it materialized rather than say 'I told you so' passively."

## 4. Practical Ways to Generate This Evidence Going Forward
- **Change project roles** (the feedback's literal suggestion) — a new team/project forces new decision dynamics where your technical opinion isn't automatically deferred to, which is exactly where "disagree and commit" gets tested and demonstrated.
- Proactively raise a technical concern in your *next* architecture/design review, in writing, with a clear recommendation and rationale — regardless of outcome, document it so it becomes a concrete story.
- After any client/manager decision you personally disagreed with, note it (privately) with: what you said, what was decided, what you did next — build a small personal log of these moments so you have 2–3 ready examples within a quarter.

## 5. Other Amazon Leadership Principles Worth Knowing Adjacent to This
(Useful since Lead-level interviews often probe more than one LP.)
- **Ownership** — "Leaders act on behalf of the entire company, beyond just their own team." (you already show strong evidence here)
- **Insist on the Highest Standards** — relevant to your naming-convention/module quality work
- **Bias for Action** — most decisions/actions are reversible and don't need extensive study (relevant to the pipeline redesign)
- **Earn Trust** — listen attentively, speak candidly even when uncomfortable (directly adjacent to Disagree and Commit)

## 6. Quick Answer Bank
- **"Tell me about a time you disagreed with your manager."** — Use the STAR template above; emphasize you led with data/reasoning, not just opinion.
- **"What do you do if you're overruled and you still think you're right?"** — Commit fully, monitor the specific risk you raised, and if it materializes, raise it again with evidence — never say "I told you so," and never quietly under-deliver on the chosen path.
- **"How is 'disagree and commit' different from just being a team player?"** — Being a team player alone can mean silently going along; this principle explicitly requires voicing the disagreement first — silence isn't the safe choice, it's actually a failure of the principle.
