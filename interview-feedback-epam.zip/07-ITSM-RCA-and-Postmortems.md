# ITSM Depth: Formal RCA & Postmortems

**Feedback addressed (Operating with Service Frameworks, gap to Advanced):** *"absence of clear evidence of designing or enhancing ITIL practices across multiple teams... limited evidence of formal RCA methods, such as the 5-Whys or structured postmortems, and a lack of postmortem enablement... no proof of expert-level implementation or enhancement of ITSM tooling at scale."*

## 1. What You Already Have (Intermediate, confirmed)
- ServiceNow incident auto-creation from monitoring alerts
- Jira for change requests and sprint planning
- Onboarding docs and service-request templates
- Defined L1 responsibilities and handoff

## 2. The 5-Whys Technique (know the mechanics, not just the name)
Ask "why" iteratively (typically 5 times, not a rigid rule) until you reach a **root** cause, not a symptom.

```
Problem: Deploy pipeline failed at 2am, paging on-call.
1. Why did it fail?           → Terraform apply timed out.
2. Why did it time out?       → State lock was held by a stuck prior run.
3. Why was the run stuck?     → A network blip during apply left the lock unreleased.
4. Why wasn't this caught?    → No lock-timeout/force-unlock alerting exists.
5. Why is there no alerting?  → Lock health was never identified as a monitored signal.
Root cause: Missing observability on state-lock health, not "flaky network."
```
**Pitfall to mention proactively (shows maturity):** 5-Whys can stop too early at a human-error answer ("engineer forgot to X") — the technique should always be pushed to a *systemic/process* root cause, not an individual one, otherwise you get blame instead of prevention.

## 3. Structured (Blameless) Postmortem Template
```
1. Summary — one paragraph, what happened, impact, duration
2. Timeline — timestamped sequence of detection, escalation, mitigation, resolution
3. Root cause(s) — via 5-Whys or similar, systemic not individual
4. Impact — quantified: users affected, revenue/SLA impact, error budget consumed
5. What went well — detection speed, comms, etc.
6. What went poorly — gaps in tooling/process
7. Action items — owner + due date for each, tracked to closure (not just written down)
```
**Blameless principle:** postmortems focus on systems/process, explicitly avoid naming individuals as "the cause" — this increases psychological safety and the honesty of what gets reported, which produces better root causes.

## 4. Where This Plugs Into Your Existing Stack
- Your ServiceNow/Prometheus alert integration already gives you the **timeline data** (alert fired at X, ack at Y, resolved at Z) — feed that directly into the "Timeline" and MTTx sections of the postmortem (see File 04).
- **Concrete next step to cite:** "I'd formalize a postmortem template triggered automatically for any Sev1/Sev2 incident in ServiceNow, with a 5-Whys section mandatory before closure — that converts our existing ad hoc incident handling into a repeatable RCA practice."

## 5. Closing the "Multiple Teams / At Scale" Gap
The recurring theme (see Overview file) is proof of doing this **beyond one team/project**. Concrete moves:
- Propose the postmortem template as an **org-wide ITSM standard**, not just for your team — present it to other Systems Engineering leads.
- Volunteer to **facilitate** (not just attend) postmortems for incidents outside your immediate project — this directly builds "Meeting Facilitation" and "ITSM at scale" evidence simultaneously.
- Track and report a rolling metric (e.g., "% of Sev1/2 incidents with a completed postmortem within 5 business days") to show ongoing ITSM ownership, not a one-off artifact.

## 6. Quick Answer Bank
- **"Walk me through how you'd run a postmortem for an incident you caused."** — Same blameless template; the point is your role in the incident doesn't change the process — the review is about the system, not you.
- **"What's the difference between an incident review and a postmortem?"** — Incident review can be operational/tactical (did we follow the runbook?); a postmortem is deeper, focused on root cause and systemic prevention, and produces tracked action items.
- **"How do you keep postmortem action items from going stale?"** — Track them as tickets with owners/due dates in the same system (Jira/ServiceNow) used for regular work, reviewed in a recurring cadence (e.g., biweekly ops review), not a static document nobody revisits.
