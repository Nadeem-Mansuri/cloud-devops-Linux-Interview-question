# Communicating Impact & Quantifying Achievements

**Feedback addressed:** *"struggles to justify choices or quantify results when under pressure... state impact in numerical terms rather than qualitative assessments such as 'customer was happy'."*

## 1. The Core Fix: Replace Qualitative Claims with a Metrics Formula

For every achievement, force it through this template:

> **Before → Action → After → Delta (with unit) → Why it mattered to the business**

| Weak (qualitative) | Strong (quantified) |
|---|---|
| "Customer was happy with the pipeline change." | "Pipeline runtime dropped from ~40 min (1 example per run) to ~9 min average across N parallel child pipelines — a ~4.4x speedup, cutting merge-to-deploy lead time and unblocking N test suites per day instead of 1." |
| "We saved a lot of money on monitoring." | "Migrated from licensed monitoring to Prometheus/Grafana/Thanos, removing $X/yr in license fees; combined with unused-resource cleanup, total savings were $50–60K/year, validated with before/after billing reports." |
| "The naming module improved consistency." | "Naming module enforces 7 standard variables (app ID, org ID, env, location, etc.) across N AWS accounts, reducing naming-related PR review comments by ~X% and aligning with the existing Azure convention used by Y teams." |

## 2. STAR-with-Numbers Template
```
Situation: <1 sentence, business context>
Task:      <what you owned>
Action:    <2-3 concrete technical actions, name the tools>
Result:    <BEFORE metric> → <AFTER metric> (<delta> / <%>), tied to a business
           outcome (cost, time, risk, reliability)
```

## 3. Ready-to-Use Quantified Talking Points (from your own feedback record)
Use these as-is or refine with your real numbers before the next session — always have the exact source (billing report, pipeline dashboard, ticket count) ready to cite if challenged.

1. **Cost cleanup:** "Led a cross-account cost cleanup that reduced cloud waste by ~$50,000–$60,000/year, backed by before/after cost-explorer reports."
2. **Pipeline redesign:** "Reworked GitLab CI to dynamically discover test subfolders and run isolated parallel child pipelines with their own state backends — moved from 1 example per pipeline run to N examples in parallel, reducing pipeline time by [X]% and unblocking concurrent testing."
3. **Naming module:** "Built and shipped a Terraform naming-convention module standardizing 7 variables across the AWS estate, adopted org-wide and aligned with the Azure team's existing convention — reducing ad-hoc naming inconsistencies across [N] accounts/projects."
4. **Monitoring stack:** "Deployed Prometheus + Grafana + Thanos with S3 long-term retention and ServiceNow alert integration, replacing a licensed tool — eliminating $[X]/yr license cost and enabling automatic incident creation for [Y] alert classes."
5. **Hiring/enablement:** "Conducted 172 interviews (75 in the last year alone), directly supporting team scaling; completed Grow to Lead training; received a client award for delivery quality."

## 4. Handling "Justify the choice" Questions Under Pressure
When asked *"why Terraform over X"* or *"why this design over that one,"* never answer with a single reason — use the **3-factor trade-off answer**:

1. **Cost/effort factor** — build time, learning curve, licensing.
2. **Operability factor** — state management, drift detection, blast radius.
3. **Team/ecosystem factor** — existing skills, multi-cloud need, vendor lock-in.

> Template: *"I chose [X] over [Y] because on [factor 1] it gave us ___, on [factor 2] the trade-off was ___, and given our team already had ___ experience, the switching cost of [Y] wasn't justified by [specific benefit]. If [condition changes], I'd revisit."*

This signals evaluated alternatives (Well-Architected "Operational Excellence" behavior) rather than a default choice — see File 02 for the IaC comparison itself.

## 5. Pressure-Test Questions to Practice Answering With Numbers
- "How much did the pipeline redesign actually save in engineering hours per week?"
- "What was the before/after MTTR after adding ServiceNow alert integration?" (tie to File 04 SRE metrics)
- "How many accounts/services adopted the naming module, and what was the defect/rework rate before vs after?"
- "What's the cost delta per environment now vs before the monitoring migration?"

**Rule of thumb:** if you can't produce a number in under 10 seconds, that story needs a metric added *before* the next assessment — go find the dashboard/report now, not in the room.
