# Financial Awareness & Market Orientation

**Feedback addressed — Financial Awareness (Novice, Intermediate required):** *"lacks advanced financial analysis and forecasting skills... absence of evidence for building financial models or forecasts... no examples of teaching or mentoring teams on financial drivers."*
**Feedback addressed — Market Orientation (Novice, Intermediate required):** *"limited broader market insight or cross-client strategy... no evidence of building or maintaining external market intelligence networks... no systematic tracking of marketplace trends or competitor analysis."*

## 1. Financial Awareness — Moving From "Found Savings" to "Forecasts Costs"
Your current evidence (cost cleanup, $50–60K/yr savings, open-source vs licensed trade-off) is genuinely good — it's **retrospective/reactive**. Intermediate needs a **forward-looking** skill: forecasting and modeling.

### Core Concept: Simple Cost Forecasting Model
```
Monthly forecast = current run-rate
                  + (planned growth: e.g., new services × avg cost/service)
                  − (planned optimizations: e.g., reserved instance / savings plan coverage)
                  ± (seasonal/traffic variance)
```
**Practical exercise to build real evidence:** Take one AWS account and build a simple 6-month cost forecast (even in a spreadsheet) using: current trend from Cost Explorer, planned infra changes (new environments, scaling events), and expected effect of any optimization (e.g., Reserved Instances / Savings Plans coverage %). This single artifact is exactly what "building financial models/forecasts" means at Intermediate level.

### Key Cost Concepts to Know By Name
| Concept | What it is |
|---|---|
| **Reserved Instances / Savings Plans** | Commit to usage for 1-3yrs for a discount (up to ~70%) vs on-demand |
| **Spot Instances** | Spare capacity at steep discount, can be reclaimed — good for fault-tolerant/batch workloads |
| **Unit economics** | Cost per unit of business value (e.g., cost per API request, per customer, per transaction) — much more meaningful to stakeholders than raw total spend |
| **Chargeback/showback** | Attributing cloud cost to the team/product that incurred it, to drive accountability |
| **TCO (Total Cost of Ownership)** | All-in cost comparison (e.g., self-hosted Prometheus/Thanos stack vs a SaaS observability vendor) including labor/operational cost, not just license/infra cost |

**Talking point tying to your monitoring migration:** "The $50-60K/yr saving was the direct license/infra delta. A full TCO view would also weigh the engineering time now spent operating Prometheus/Thanos ourselves versus a managed vendor — that's the kind of trade-off a more mature financial-awareness answer should include, even if the net conclusion is the same."

### Mentoring on Financial Drivers (explicit gap called out)
- Simple, low-effort way to build this evidence: run a short session with your team explaining *why* a cost decision was made (e.g., "here's how Reserved Instance coverage works and why we're targeting 70% coverage on steady-state workloads") — this single act closes "no examples of mentoring on financial drivers."

## 2. Market Orientation — Moving From Single-Client to Market-Level Thinking
Your current evidence is deep but concentrated on one long-term client (LSEG). Intermediate needs evidence of **broader market/industry awareness**, not necessarily multi-client delivery experience.

### Practical, Low-Effort Ways to Build This Evidence
1. **Follow 2–3 industry sources regularly** (AWS "What's New," CNCF landscape updates, a DevOps/SRE newsletter) and be ready to cite a recent trend (e.g., "platform engineering" and internal developer platforms becoming the dominant framing for DevOps teams industry-wide, or FinOps maturing as a discipline).
2. **Competitor/alternative awareness for your own tooling choices** — e.g., know that Datadog/New Relic/Grafana Cloud are the commercial alternatives to your self-hosted Prometheus stack, and be able to say *why* self-hosted was still the right call for your context (cost at your scale, no vendor data residency concerns, etc.) — this reframes a client-specific decision as market-aware.
3. **Cross-client pattern-spotting** — even without another named client, you can speak to *how the naming-convention/monitoring patterns you built would generalize* to a similar client — showing you think beyond one account.

**Talking point:** "My deepest experience is with one client, LSEG, but the patterns I've built — the naming module's 7-variable schema, the Prometheus/Thanos stack, the ITSM alert integration — aren't LSEG-specific; they reflect broader industry patterns (e.g., most enterprises converge on a similar small set of naming variables, and the shift from licensed to open-source observability tooling is an industry-wide FinOps trend, not just this client's preference)."

## 3. A Combined 90-Day Action Plan for This File
1. Build one real 3–6 month cost forecast for a live account (Financial Awareness evidence).
2. Run one 20-minute session with your team explaining a financial trade-off you made (mentoring evidence).
3. Pick 2 industry trends (e.g., FinOps, platform engineering) and be ready to discuss them unprompted in your next session (Market Orientation evidence).
4. Write one paragraph connecting your naming/monitoring work to "how this generalizes beyond this client" — reuse it in any future assessment.

## 4. Quick Answer Bank
- **"How would you decide between Reserved Instances and Savings Plans?"** — RIs are more restrictive (tied to instance family/region) but can be cheaper for very stable workloads; Savings Plans offer more flexibility (compute-agnostic within a commitment) at a slightly smaller discount — pick based on how stable/predictable the workload shape is.
- **"What's a market trend you're tracking right now?"** — Have a genuine, current one ready (e.g., FinOps practices maturing, platform engineering/internal developer platforms, AI-assisted infra tooling) rather than improvising in the room.
- **"How do you decide if a cost optimization is worth the engineering effort?"** — Compare the engineering time cost (hours × loaded rate, roughly) against the annualized savings — a simple payback-period framing is enough to show financial rigor without needing formal finance training.
