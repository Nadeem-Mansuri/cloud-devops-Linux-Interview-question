# GenAI-Assisted Engineering Productivity (Expert-level gap)

**Feedback addressed:** *"Address the lack of evidence regarding GenAI-assisted engineering productivity in presentations... key skill expected at the current level."* Skill comment also notes: *"lack of evidence regarding the configuration and tuning of LLM model parameters or fine-tuning models... limited evidence of benchmarking model choices or building modular prompt libraries... absence of organizational mentoring or governance for LLM adoption."*

You already have real material here (Copilot usage + Teragen prototype with LangChain/Azure AI + planned RAG). The gap is **presenting it with rigor**, not lacking the work. This file gives you the vocabulary and structure to present it at Expert level.

## 1. Reframe What You've Already Done Using the Right Vocabulary

| What you did | Expert-level term to use |
|---|---|
| Using GitHub Copilot day-to-day | "LLM-assisted code generation integrated into the IDE workflow" |
| Building Teragen with LangChain + Azure AI | "Retrieval-Augmented Generation (RAG) pipeline using an orchestration framework (LangChain) over an internal knowledge corpus" |
| Planned RAG over internal repos | "Grounding generation in internal repositories to reduce hallucination and enforce house coding standards" |
| Goal: generate standardized modules | "Prompt-driven scaffolding constrained to organizational templates" |

## 2. The Three Gaps Called Out — Close Each Explicitly

### Gap A: LLM configuration/tuning
Be ready to discuss, even at a conceptual level:
- **Temperature** — controls randomness (low = deterministic/safe for code gen, high = creative)
- **Top-p / top-k sampling** — alternative ways to constrain token selection
- **Context window management** — chunking strategy for RAG so retrieved context fits the model's window
- **Fine-tuning vs prompt-engineering vs RAG** — know when each applies:
  - *Prompt engineering*: fastest, no training needed, good for well-specified tasks
  - *RAG*: adds fresh/internal knowledge without retraining — right fit for "generate modules per our internal conventions"
  - *Fine-tuning*: changes model weights, needed when you need consistent *style/format* the base model can't be prompted into reliably, or want to bake in proprietary patterns permanently — higher cost, more maintenance
- **Your answer:** "For Teragen, RAG was the right choice over fine-tuning because our internal Terraform templates change frequently — fine-tuning would require re-training every time conventions evolve, whereas RAG just needs the retrieval corpus refreshed."

### Gap B: Benchmarking model choices / prompt libraries
- **Benchmarking**: compare candidate models (e.g., GPT-4 class vs a smaller/cheaper model) on a fixed eval set of your own tasks (e.g., "generate a Terraform module matching our naming convention") using objective criteria: correctness (does it compile/plan clean), adherence to convention, latency, cost per generation.
- **Prompt libraries**: a versioned, reusable set of prompt templates (e.g., "generate-terraform-module.prompt", "explain-runbook.prompt") stored in source control, parameterized, and tested like code — this is what "modular prompt libraries" means.
- **Your answer:** "The next iteration of Teragen should include a small benchmark set of representative module-generation tasks, scored against our naming/style conventions, so we can justify model or prompt changes with data instead of anecdote — that's the concrete next step I'd commit to."

### Gap C: Organizational mentoring/governance for LLM adoption
- **Governance topics to be able to speak to:** data privacy (what internal data is allowed in prompts/context), license/IP concerns for AI-generated code, review requirements for AI-generated infra changes (should always go through the same PR/plan review as human-written code), and a rollout plan (pilot team → broader team → org).
- **Your answer:** "The gap the panel flagged is fair — I've used GenAI myself and built a prototype, but haven't yet run enablement sessions for others. My plan is to turn the Teragen prototype into a short internal workshop/demo once RAG-grounding is in place, plus a lightweight guideline doc on what internal data can/can't go into prompts."

## 3. A Structured "Presentation-Ready" Narrative
```
1. Problem: Manual Terraform module authoring is repetitive and error-prone re: naming/conventions.
2. Approach: Prototyped "Teragen" — LangChain + Azure AI, moving toward RAG grounded in
   internal repos so generated modules follow house conventions automatically.
3. Why RAG (not fine-tuning): conventions change often; RAG avoids retraining costs.
4. Current adoption: personal use of Copilot in daily dev work.
5. Gaps I own: no formal benchmarking yet, no prompt library, no governance/rollout plan.
6. Next 90 days: build a 5-10 task benchmark set, template the prompt library in source
   control, draft a one-page data-handling guideline, run one enablement session.
```
This structure alone answers "lack of evidence" — it shows you know exactly what Expert-level evidence looks like and have a concrete plan to produce it.

## 4. Quick Answer Bank
- **"How would you evaluate whether GenAI is actually improving productivity?"** — Track cycle time for a defined task type (e.g., module scaffolding) before/after, plus a quality gate (does generated code pass plan/lint/tests unmodified, or how much rework is needed).
- **"What are the risks of RAG grounding on internal repos?"** — Stale or inconsistent source docs get reproduced as "correct" patterns; need a curation/refresh process for the retrieval corpus.
- **"How do you keep AI-generated infra code accountable?"** — Same review gates as any code: PR review, `terraform plan` review, CI tests — AI-generated is not exempt from the standard change process.
