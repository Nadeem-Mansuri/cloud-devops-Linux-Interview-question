# Terraform Naming Convention Patterns

**Feedback addressed (required dev item):** *"Explore the use of the format function, string interpolation, templatefile function with external file templates, and locals with standardized patterns to adhere to naming conventions in Terraform."*

This directly extends your existing naming module work (7 standard variables: app ID, org ID, environment, location, etc.) — the ask is to demonstrate command over the *implementation techniques*, not just the module's existence.

## 1. `locals` block — the standardized-pattern hub
```hcl
locals {
  # Canonical variable set your module already uses
  app_id      = var.app_id
  org_id      = var.org_id
  environment = var.environment   # e.g. dev / stg / prod
  location    = var.location      # e.g. eus, weu

  # Single source of truth for the naming pattern
  name_prefix = "${local.org_id}-${local.app_id}-${local.environment}-${local.location}"

  # Per-resource-type suffixes, still driven from the same locals
  resource_names = {
    vpc            = "${local.name_prefix}-vpc"
    s3_bucket      = "${local.name_prefix}-s3"
    ec2_instance   = "${local.name_prefix}-ec2"
    security_group = "${local.name_prefix}-sg"
  }
}
```
**Why this matters for the interview:** `locals` centralizes the pattern so every resource block references `local.resource_names.xxx` instead of re-deriving the string — this is what lets you say "consistency is enforced structurally, not by convention/discipline."

## 2. `format()` function — precise, printf-style control
```hcl
resource "aws_s3_bucket" "this" {
  bucket = format("%s-%s-%s-%s", var.org_id, var.app_id, var.environment, var.location)
}
```
Use `format()` when you need **padding, ordering guarantees, or type coercion** (e.g. zero-padding an index: `format("%s-%03d", local.name_prefix, count.index)`), which plain interpolation can't do cleanly.

## 3. String interpolation — the everyday tool
```hcl
resource "aws_security_group" "this" {
  name = "${local.name_prefix}-sg-${var.purpose}"
}
```
Simple, readable, best for straightforward concatenation. The trade-off vs `format()`: interpolation is easier to read for simple cases, but `format()` is better once you need numeric formatting/padding or reuse the same pattern across many resource types with strict argument ordering.

## 4. `templatefile()` — externalizing complex naming/config templates
```hcl
# naming.tftpl
${org_id}-${app_id}-${environment}-${location}-${resource_type}
```
```hcl
locals {
  vpc_name = templatefile("${path.module}/templates/naming.tftpl", {
    org_id        = var.org_id
    app_id        = var.app_id
    environment   = var.environment
    location      = var.location
    resource_type = "vpc"
  })
}
```
**Why use this over inline interpolation:** once the naming logic gets complex (e.g. conditional segments, multiple naming schemes per resource family, or you want non-Terraform-literate stakeholders to review/edit the pattern), externalizing to a `.tftpl` file separates "the pattern" from "the plumbing" — this is the kind of design decision the panel wants you to *justify*, not just use.

## 5. Putting it together — a small reusable naming module
```hcl
# modules/naming/variables.tf
variable "org_id"      { type = string }
variable "app_id"      { type = string }
variable "environment" { type = string }
variable "location"    { type = string }

# modules/naming/main.tf
locals {
  base = "${var.org_id}-${var.app_id}-${var.environment}-${var.location}"
}

output "name_for" {
  value = { for k, v in {
    vpc = "vpc", s3 = "s3", ec2 = "ec2", sg = "sg"
  } : k => format("%s-%s", local.base, v) }
}
```
Consumers do: `module "naming" { source = "./modules/naming" ... }` then `module.naming.name_for["vpc"]`.

## 6. Talking Points for the Assessment
- "We centralize the 7 standard variables in `locals`, so every resource type derives its name from one source of truth rather than duplicating string logic."
- "We use `format()` where ordering/padding matters (e.g., numbered instances in an ASG), and plain interpolation for simple concatenation — that's a deliberate readability-vs-precision trade-off, not an accident."
- "For the more complex naming schemes (multi-segment, conditional), we'd externalize to `templatefile()` so the pattern itself is reviewable independent of the Terraform logic that consumes it."
- "This mirrors the Azure team's existing convention, which is why interoperability was a design constraint from day one."

## 7. Common Pitfalls to Mention Proactively (shows depth)
- Hardcoding separators (`-` vs `_`) inconsistently across resource types that have different naming restrictions (e.g., S3 bucket names can't contain underscores or uppercase).
- Not validating length limits (S3: 63 chars, some Azure resources: much shorter) — mention using `substr()` or truncation logic defensively.
- Not versioning the naming module itself — a breaking change to the pattern should be a major version bump, since renames can force resource replacement.
