# SRE Foundations — SLI, SLO, SLA, Golden Signals, Error Budget, MTTx

**Feedback addressed:** *"Deepen knowledge of SRE foundations including MTTx, SLI, SLO, SLA, Golden Signals, and Error Budget."* Also cited under Monitoring Implementation: *"lacks formal criticality and SLA metrics... absence of measured user-experience KPIs, such as golden signals and MTTx."*

## 1. The Core Definitions (memorize these exactly)

| Term | Definition | Example |
|---|---|---|
| **SLI** (Service Level Indicator) | A quantitative measure of some aspect of the service level | "% of requests served in <300ms", "% of successful HTTP 2xx responses" |
| **SLO** (Service Level Objective) | An internal target value/range for an SLI over time | "99.9% of requests succeed over a rolling 30-day window" |
| **SLA** (Service Level Agreement) | An external, often contractual, commitment with consequences (credits/penalties) for missing it | "99.95% uptime or customer receives service credits" |
| **Error Budget** | `1 − SLO` — the amount of unreliability you're allowed before violating the SLO | If SLO = 99.9%, error budget = 0.1% of requests/time can fail without breaching |
| **MTTx family** | Mean Time To X — operational speed metrics | See below |

**Relationship to remember:** SLA ⊇ SLO ⊇ SLI. The SLA is usually looser than the internal SLO (so you have margin before breaching a contract), and the SLO is what you actually alert/operate against; the SLI is the raw measurement feeding it.

## 2. The MTTx Family

| Metric | Meaning |
|---|---|
| **MTTD** | Mean Time To Detect — how long from incident start to detection/alert firing |
| **MTTA** | Mean Time To Acknowledge — from alert to a human acknowledging it |
| **MTTR** | Mean Time To Resolve/Repair — from acknowledgment (or detection) to resolution |
| **MTTF** | Mean Time To Failure — average time a system runs before failing (reliability of hardware/components) |
| **MTBF** | Mean Time Between Failures — MTTF + MTTR, i.e., failure-to-failure interval |

**Talking point tying to your monitoring work:** "Our ServiceNow integration auto-creates incidents from Prometheus alerts, which directly reduces MTTD and MTTA since detection and ticket creation are the same event — the gap the panel correctly flagged is that we haven't yet *measured and reported* MTTR/MTTD trends over time; that's a reporting gap, not a tooling gap, and it's the fastest of these items to close."

## 3. The Four Golden Signals (Google SRE)
1. **Latency** — time to service a request (separate successful vs failed request latency!)
2. **Traffic** — demand on the system (requests/sec, concurrent sessions)
3. **Errors** — rate of failed requests (explicit failures + implicit, e.g. wrong content)
4. **Saturation** — how "full" the service is (CPU, memory, queue depth, I/O)

**Apply to your stack:** "With Prometheus scraping infra + app metrics and Grafana dashboards, we already collect Traffic and Saturation well. Latency is partially covered; Errors is covered at the infra level via alerting rules. The gap is we don't yet split latency/error SLIs by *user-facing* transaction type — that's the 'golden signals maturity' step up from basic infra monitoring to true observability."

## 4. Error Budget Policy — how it's actually used
- If the error budget is **not exhausted**, teams can ship features/take risks (deploy velocity is fine).
- If the error budget **is exhausted**, the policy typically freezes risky changes and prioritizes reliability work until the budget replenishes.
- This is the mechanism that resolves the classic "Dev wants velocity, Ops wants stability" tension **objectively**, using data instead of debate.

**Sample answer if asked "how would you introduce error budgets to your team":**
> "First define an SLI per critical user journey (e.g., API success rate), set an SLO with the business (e.g., 99.9%), and instrument it via our existing Prometheus stack. Then agree an error-budget policy: burn-rate alerts (fast burn = page immediately, slow burn = ticket) and a change-freeze rule when budget is exhausted. This gives us a data-driven way to balance our deploy cadence against reliability, versus today's more ad hoc alerting."

## 5. Burn Rate Alerting (mention if asked "how would you alert on this")
- **Burn rate** = how fast you're consuming the error budget relative to the SLO window.
- Multi-window, multi-burn-rate alerts (Google SRE Workbook pattern): e.g., alert loudly if burning the budget fast enough to exhaust it in 1 hour (2% budget in 5 min window), alert quieter/ticket if a slower burn would exhaust it in a few days.

## 6. Quick Answer Bank
- **"What's the difference between SLO and SLA?"** — SLO is internal target used to drive engineering decisions; SLA is the external, often contractual promise with consequences. SLA thresholds are usually looser than SLOs to create margin.
- **"How would you pick your first SLI for a service you don't monitor at all yet?"** — Start with availability/success-rate on the primary user-facing endpoint; it's the simplest, most business-relevant signal and a natural gateway to adding latency SLIs next.
- **"What's the risk of only alerting on infra metrics (CPU/mem) instead of golden signals?"** — You can be "green" on infra while users experience errors/latency (e.g., app-level exceptions, downstream dependency failure) — infra health ≠ user-experienced health.

## 7. Recommended Deep-Dive Resources (as cited in your feedback)
- Introduction to SRE talk: https://wearecommunity.io/events/sre-conference/talks/70776
- SRE Governance talk: https://wearecommunity.io/events/sre-governance/talks/74218
- Google SRE Book (free): https://sre.google/books/
