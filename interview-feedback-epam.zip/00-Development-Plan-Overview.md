# Development Plan — Systems Engineering L3 → Lead Systems Engineer (L4)
**Candidate:** Nadeem Mansuri | **Discipline:** Cloud Operations | **Overall Mark:** Ready for promotion, with development plan

## 1. Verdict Summary
The panel recommends promotion to **Lead Systems Engineer** with an *optional* improvement plan. Nothing flagged is a hard skills gap — the two recurring themes across almost every skill comment are:

1. **Depth/breadth at scale** — most gaps are versions of "hasn't done X *across multiple teams / org-wide / at enterprise scale*" rather than "doesn't know X."
2. **Communication discipline** — solid execution, but under-explains *why* (trade-offs) and *how much* (quantified impact).

## 2. Skill Scorecard (Required vs Current Level)

| Skill | Required | Current | Gap? |
|---|---|---|---|
| Cloud Operations | Expert | Advanced | Yes — 1 level |
| Operating with Service Frameworks (ITSM) | Advanced | Intermediate | Yes — 1 level |
| OS Administration | Expert | Intermediate | Yes — 2 levels |
| DevOps | Advanced | Advanced | On level |
| Developing Others | Intermediate | Intermediate | On level |
| Container Orchestration Management | Advanced | Intermediate | Yes — 1 level |
| Automation (Scripting) | Advanced | Advanced | On level |
| IaC Development & Maintenance | Intermediate | Intermediate | On level |
| Monitoring Implementation & Maintenance | Advanced | Intermediate | Yes — 1 level |
| Problem-solving | Intermediate | Intermediate | On level |
| Consultancy | Novice | Intermediate | Exceeds |
| Delivery Excellence | Novice | Novice | On level |
| Managing Teamwork | Intermediate | Intermediate | On level |
| Mentoring | Novice | Novice | On level |
| Market Orientation | Intermediate | Novice | Yes — 1 level |
| Financial Awareness | Intermediate | Novice | Yes — 1 level |
| Client Relationship Management | Intermediate | Intermediate | On level |
| Communication | Intermediate | Intermediate | On level |
| Ownership | Intermediate | Intermediate | On level |
| Business Acumen | Intermediate | Intermediate | On level |
| Meeting Facilitation | Novice | Novice | On level |
| Driving Change & Innovation | Intermediate | Intermediate | On level |
| Adaptability | Intermediate | Intermediate | On level |
| Leadership | Intermediate | Intermediate | On level |
| Source Code Management | Intermediate | Intermediate | On level |
| Containerization | Advanced | Intermediate | Yes — 1 level |
| SDLC Frameworks | Advanced | Advanced | On level |
| Network Administration | Intermediate | Intermediate | On level |
| Virtualization Config & Maintenance | Advanced | Intermediate | Yes — 1 level |
| Database Config & Maintenance | Intermediate | Intermediate | On level |
| Being a Team Player | Intermediate | Intermediate | On level |
| GenAI for Systems Engineering Productivity | Expert | Advanced | Yes — 1 level |

**Priority gaps (biggest lever, most repeated across experts):** Cloud Operations (Expert), OS Administration (Expert, 2-level gap), GenAI Productivity (Expert), Monitoring/Observability (Advanced), Container Orchestration (Advanced), Containerization (Advanced), Virtualization (Advanced), ITSM (Advanced).

## 3. The Required Development Plan Items (from feedback, verbatim themes)
1. Terraform naming-convention patterns (`format`, string interpolation, `templatefile`, `locals`)
2. SRE foundations (MTTx, SLI, SLO, SLA, Golden Signals, Error Budget)
3. OpenTelemetry fundamentals
4. Project management / leadership — "Have Backbone; Disagree and Commit"
5. Quantifying achievements — numeric before/after framing instead of qualitative claims
6. Evaluating options in technical decisions — Well-Architected Framework's 6 pillars, Terraform vs CloudFormation vs CDK, 12-factor app methodology
7. GenAI-assisted engineering productivity — needs demonstrable evidence, not just tool usage

## 4. Study Plan and File Map
Each numbered file below is a self-contained prep guide with the actual answers, comparisons, and talking points to close a specific gap, so the next assessment (or interview) can draw on them directly.

| # | File | Closes Gap(s) |
|---|---|---|
| 01 | Communicating Impact & Quantifying Achievements | Communication of Impact, Financial Awareness |
| 02 | Well-Architected Framework & IaC Trade-offs | Evaluating Options, Cloud Operations (Expert depth) |
| 03 | Terraform Naming Convention Patterns | Required dev item #1, IaC |
| 04 | SRE Foundations (SLI/SLO/SLA/MTTx/Golden Signals) | Monitoring, Cloud Operations |
| 05 | OpenTelemetry & Observability | Monitoring, Containerization |
| 06 | GenAI-Assisted Engineering Productivity | GenAI skill (Expert) |
| 07 | ITSM, RCA & Postmortems | Operating with Service Frameworks |
| 08 | Leadership — Have Backbone; Disagree and Commit | Leadership, Project Management |
| 09 | Advanced Networking — Direct Connect via IaC | Network Administration, Cloud Ops |
| 10 | Advanced Containerization & Orchestration | Container Orchestration, Containerization |
| 11 | OS Administration & Virtualization at Expert Level | OS Administration, Virtualization |
| 12 | Financial Awareness & Market Orientation | Financial Awareness, Market Orientation |

## 5. 90-Day Cadence
- **Weeks 1–2:** Files 01–03 (communication + Well-Architected + Terraform patterns) — highest leverage, lowest effort, fixes the most-repeated critique.
- **Weeks 3–5:** Files 04–06 (SRE, OpenTelemetry, GenAI) — closes the Expert-tier Cloud Operations and GenAI gaps.
- **Weeks 6–8:** Files 07–10 (ITSM/RCA, leadership, networking, containers) — closes Advanced-tier gaps.
- **Weeks 9–12:** File 11–12 (OS/virtualization depth, financial/market) + rebuild 2–3 STAR stories using the quantification framework in File 01, ideally sourced from a *second* client or org-wide initiative to answer the "only one client / not org-wide" critique running through the feedback.

## 6. Cross-Cutting Theme to Fix Everywhere
Nearly every "gap" comment reduces to: *"no evidence of doing this across multiple teams / the whole org / enterprise scale."* The single highest-leverage action independent of any technical file is to **actively seek one cross-team or org-wide initiative** (e.g., propose the naming module or monitoring stack as an org standard, not just a project deliverable) and document it with metrics — this simultaneously helps Cloud Operations, ITSM, Market Orientation, and Leadership scores.
