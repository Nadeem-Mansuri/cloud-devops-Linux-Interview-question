# Advanced Networking: Direct Connect via IaC

**Feedback addressed:** *"a lack of hands-on experience with complex hybrid-network implementations, particularly regarding Direct Connect detailed provisioning via IaC."* You already correctly explain Direct Connect vs VPN conceptually — the gap is *provisioning depth*, not concept knowledge.

## 1. Where You Already Are (confirmed strength)
- Recommend Transit Gateway for hub-and-spoke topology
- Understand Direct Connect vs site-to-site VPN trade-off (throughput/latency/cost vs setup speed)
- Use centralized network accounts + checkpoint firewalls

## 2. Direct Connect Architecture Components (know each, be ready to provision conceptually)
| Component | Purpose |
|---|---|
| **Connection** | The physical cross-connect at an AWS Direct Connect location (owned by you or a partner) |
| **Virtual Interface (VIF)** | Logical interface over the connection — **Private VIF** (to VPC via VGW/DXGW), **Public VIF** (to AWS public services), **Transit VIF** (to a Transit Gateway) |
| **Direct Connect Gateway (DXGW)** | Lets one Direct Connect connection reach multiple VPCs across regions/accounts |
| **Virtual Private Gateway (VGW)** | VPC-side endpoint attached per-VPC (older model, being superseded by Transit Gateway attachments) |
| **LAG (Link Aggregation Group)** | Bundles multiple physical connections for higher bandwidth/redundancy |
| **BGP** | Routing protocol used over the VIF for dynamic route exchange with AWS |

## 3. Terraform Skeleton for Direct Connect (the "detailed provisioning via IaC" evidence)
```hcl
resource "aws_dx_gateway" "this" {
  name            = "org-dxgw"
  amazon_side_asn = 64512
}

resource "aws_dx_gateway_association" "to_tgw" {
  dx_gateway_id         = aws_dx_gateway.this.id
  associated_gateway_id = aws_ec2_transit_gateway.this.id
  allowed_prefixes      = ["10.0.0.0/8"]
}

resource "aws_dx_transit_virtual_interface" "this" {
  connection_id    = var.dx_connection_id     # existing physical connection
  dx_gateway_id    = aws_dx_gateway.this.id
  name             = "org-transit-vif"
  vlan             = 100
  address_family   = "ipv4"
  bgp_asn          = 65000
}
```
**Talking point:** "Provisioning the physical cross-connect itself is a manual/carrier process, but everything from the Direct Connect Gateway down — the transit VIF, the Transit Gateway association, allowed prefixes, and BGP ASN — is fully codified in Terraform, so the logical network topology is versioned and repeatable even though the physical layer isn't."

## 4. Direct Connect vs VPN — Full Trade-off (go one level deeper than "throughput")
| Factor | Direct Connect | Site-to-Site VPN |
|---|---|---|
| Bandwidth | Dedicated, 1/10/100 Gbps | Capped (~1.25 Gbps per tunnel typically) |
| Latency | Lower and more consistent (private line) | Variable (traverses public internet) |
| Setup time | Weeks (physical cross-connect + carrier) | Minutes (software-only) |
| Cost model | Port-hour + data transfer, higher fixed cost | Pay-as-you-go, lower fixed cost |
| Encryption | Not encrypted by default (add MACsec or run VPN over DX for encryption) | Encrypted (IPsec) by design |
| Redundancy pattern | LAG + secondary connection at different location | Multiple tunnels across different VPN endpoints, cheaper redundancy |
| Best fit | Sustained high-throughput, latency-sensitive, or large steady data transfer | Fast setup, lower/variable volume, or as DX backup path |

**Common combined pattern to mention:** "VPN as a backup path over the internet in case the Direct Connect circuit fails" — this is a frequently-asked design question and shows you think in terms of resilience, not just primary-path selection.

## 5. Hybrid Network Topology (hub-and-spoke, tie back to Transit Gateway)
```
On-prem DC ---(Direct Connect)--- DX Gateway ---(Transit VIF)--- Transit Gateway
                                                                        |
                                                        -----------------------------
                                                        |            |              |
                                                     VPC A        VPC B          VPC C
                                                    (spoke)      (spoke)        (spoke)
```
**Talking point:** "Centralizing through a Transit Gateway rather than per-VPC VGW attachments means new spoke VPCs just need a TGW attachment — no new Direct Connect configuration per VPC, which is the scalability argument for hub-and-spoke over point-to-point."

## 6. What "Expert/Advanced" Evidence Would Look Like Next
- A real (even if lab/POC) Terraform module provisioning DXGW + transit VIF + TGW association end-to-end
- A documented BGP route-propagation/failover test (what happens if the DX connection drops — does traffic actually fail over to VPN or a second DX circuit?)
- Cost modeling comparing DX port-hour + data-transfer cost vs VPN + higher latency cost for a specific projected traffic volume (ties into Financial Awareness, File 12)

## 7. Quick Answer Bank
- **"What happens if BGP flaps on your Direct Connect connection?"** — Routes are withdrawn/re-advertised; with a properly configured VPN backup and correct route priorities (or BGP path prepending), traffic should fail over automatically — worth explicitly testing, not just assuming.
- **"How would you secure data over Direct Connect since it's not encrypted by default?"** — Either enable MACsec (if the DX location supports it) or run an IPsec VPN tunnel over the DX connection for sensitive traffic.
- **"Why Direct Connect Gateway instead of attaching VGWs per VPC?"** — DXGW lets one physical connection serve many VPCs/accounts/regions, avoiding a proliferation of per-VPC gateway associations as the estate grows.
